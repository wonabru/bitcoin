#define IDI_ICON                        1

#define IDS_EXTRACTION_ERROR_TITLE      7
#define IDS_EXTRACTION_ERROR_MESSAGE    8
#define IDS_CANNOT_CREATE_FOLDER        9
#define IDS_PROGRESS_EXTRACTING         69
